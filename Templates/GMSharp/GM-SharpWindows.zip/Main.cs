﻿#region Using Statements
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using GMSharp;
using GMSharp.Resources;
#endregion

namespace $safeprojectname$
{
    public class Main : GMSharpGame
    {
        public Main()
        {
            Resources.Define();
        }
    }
}
